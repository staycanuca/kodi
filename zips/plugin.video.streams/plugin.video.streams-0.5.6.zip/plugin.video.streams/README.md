plugin.video.streams
====================

streams plugin for xbmc
